"use client";

import { Search, MapPin, Calendar, Target, SlidersHorizontal, ChevronDown } from "lucide-react";

export default function SearchBar({ searchQuery, setSearchQuery }) {
  return (
    <div className="bg-black border-y border-white/5 relative overflow-hidden">
      {/* Subtle Background Glow */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-64 h-24 bg-lime-400/10 blur-[100px] pointer-events-none" />
      
      <div className="max-w-[1440px] mx-auto px-6 py-8 md:py-12">
        <div className="relative group">
          {/* Labeling */}
          <div className="flex items-center justify-between mb-4 px-2">
            <div className="flex items-center gap-2">
              <span className="h-1 w-8 bg-lime-400 rounded-full" />
              <h2 className="text-[10px] uppercase font-black tracking-[0.3em] text-white/40">
                Arena Discovery Engine
              </h2>
            </div>
            <div className="hidden md:flex items-center gap-4 text-[10px] font-black uppercase text-lime-400/60 tracking-widest">
              <span>82 Venues Active</span>
              <span className="h-1 w-1 rounded-full bg-white/20" />
              <span>Karachi, PK</span>
            </div>
          </div>

          {/* THE SEARCH CHASSIS */}
          <div className="bg-[#0A0A0A] border border-white/10 rounded-2xl md:rounded-full p-2 flex flex-col md:flex-row items-stretch md:items-center gap-2 shadow-2xl transition-all duration-500 hover:border-white/20">
            
            {/* Input Section */}
            <div className="flex-1 flex items-center gap-4 px-5 py-3 md:py-0">
              <Search size={20} className="text-lime-400" />
              <input
                className="bg-transparent text-base w-full focus:outline-none placeholder:text-white/20 font-medium italic"
                placeholder="Search by sport, venue name, or area..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Divider (Desktop Only) */}
            <div className="hidden md:block h-10 w-px bg-white/5" />

            {/* Location Selector */}
            <button className="flex items-center justify-between md:justify-start gap-3 px-5 py-3 md:py-0 hover:bg-white/5 transition-colors rounded-xl md:rounded-none group/item">
              <div className="flex items-center gap-3">
                <MapPin size={18} className="text-white/40 group-hover/item:text-lime-400 transition-colors" />
                <div className="text-left">
                  <p className="text-[9px] uppercase font-black text-white/30 leading-none mb-1">Location</p>
                  <p className="text-sm font-bold text-white truncate">Karachi, PK</p>
                </div>
              </div>
              <ChevronDown size={14} className="text-white/20" />
            </button>

            {/* Divider (Desktop Only) */}
            <div className="hidden md:block h-10 w-px bg-white/5" />

            {/* Date Selector */}
            <button className="flex items-center justify-between md:justify-start gap-3 px-5 py-3 md:py-0 hover:bg-white/5 transition-colors rounded-xl md:rounded-none group/item">
              <div className="flex items-center gap-3">
                <Calendar size={18} className="text-white/40 group-hover/item:text-lime-400 transition-colors" />
                <div className="text-left">
                  <p className="text-[9px] uppercase font-black text-white/30 leading-none mb-1">Timing</p>
                  <p className="text-sm font-bold text-white whitespace-nowrap">Today, Feb 08</p>
                </div>
              </div>
              <ChevronDown size={14} className="text-white/20" />
            </button>

            {/* Search Button / Filter Icon */}
            <div className="flex items-center gap-2 p-1">
              <button className="hidden sm:flex items-center justify-center bg-white/5 hover:bg-white/10 h-12 w-12 rounded-xl md:rounded-full border border-white/5 transition-all">
                <SlidersHorizontal size={18} className="text-white" />
              </button>
              <button className="flex-1 md:flex-none px-8 h-12 bg-lime-400 text-black font-black uppercase italic text-sm tracking-tighter rounded-xl md:rounded-full hover:bg-white transition-all transform active:scale-95 shadow-[0_0_20px_rgba(163,230,53,0.3)]">
                Find Slots
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative Target Icon (Updated Position) */}
      <Target size={120} className="absolute -bottom-10 -right-10 text-white/[0.02] pointer-events-none" />
    </div>
  );
}