"use client";

import { MapPin, Star, ArrowUpRight, Shield, Zap } from "lucide-react";
import Link from "next/link";

export default function VenueCard({ venue }) {
  return (
    <Link href={`/venue/${venue.id}`} className="block h-full">
      {/* Container: h-full ensures all cards in the grid row match height */}
      <div className="group relative h-full bg-[#0D0D0D] border border-white/10 flex flex-col transition-all duration-300 hover:border-lime-400">
        
        {/* TOP SECTION: IMAGE AREA */}
        <div className="relative h-56 w-full overflow-hidden bg-[#151515]">
          {/* Angular Sport Tag */}
          <div className="absolute top-0 left-0 z-20 bg-lime-400 text-black px-4 py-1 text-[10px] font-black uppercase tracking-[0.2em] [clip-path:polygon(0_0,100%_0,80%_100%,0%_100%)]">
            {venue.sport}
          </div>

          <img
            src={venue.image}
            className="w-full h-full object-cover opacity-90 transition-all duration-700 group-hover:scale-110 group-hover:opacity-100"
            alt={venue.name}
          />

          {/* Price Overlay - High Contrast */}
          <div className="absolute bottom-0 right-0 z-20 bg-black/90 backdrop-blur-md px-4 py-2 border-t border-l border-white/10">
            <div className="flex flex-col items-end">
              <span className="text-[8px] font-bold text-white/40 uppercase leading-none">Hourly Rate</span>
              <span className="text-lg font-black text-white leading-none mt-1">
                <span className="text-lime-400 text-xs mr-1">PKR</span>{venue.price}
              </span>
            </div>
          </div>
        </div>

        {/* MIDDLE SECTION: PRIMARY DATA (Flex-1 ensures even expansion) */}
        <div className="p-5 flex-1 flex flex-col">
          <div className="flex justify-between items-start gap-4">
            <h3 className="text-xl font-black uppercase italic tracking-tighter leading-[0.9] text-white">
              {venue.name}
            </h3>
            <div className="shrink-0 bg-white/5 p-2 rounded-sm border border-white/10 group-hover:bg-lime-400 group-hover:text-black transition-colors">
              <ArrowUpRight size={16} />
            </div>
          </div>

          <div className="flex items-center gap-1.5 mt-3 text-white/40">
            <MapPin size={12} className="text-lime-400" />
            <span className="text-[10px] font-bold uppercase tracking-widest">{venue.area}</span>
          </div>

          {/* Technical Specs Row */}
          <div className="mt-auto pt-6 flex items-center gap-4">
            <div className="flex flex-col">
              <span className="text-[8px] font-bold text-white/20 uppercase tracking-tighter">Performance</span>
              <div className="flex items-center gap-1 mt-0.5">
                <Star size={10} fill="#a3e635" className="text-lime-400" />
                <span className="text-xs font-black text-white">{venue.rating}</span>
              </div>
            </div>
            
            <div className="h-6 w-px bg-white/5" />

            <div className="flex flex-col">
              <span className="text-[8px] font-bold text-white/20 uppercase tracking-tighter">Status</span>
              <div className="flex items-center gap-1 mt-0.5">
                <Zap size={10} className="text-lime-400" />
                <span className="text-[9px] font-bold text-lime-400 uppercase">Available</span>
              </div>
            </div>
          </div>
        </div>

        {/* BOTTOM SECTION: STATIC UTILITY STRIP */}
        <div className="bg-white/5 px-5 py-3 flex items-center justify-between border-t border-white/10">
          <div className="flex gap-2">
            <div className="h-3 w-3 rounded-full border border-white/20 flex items-center justify-center p-[2px]">
                <div className="h-full w-full bg-lime-400 rounded-full animate-pulse" />
            </div>
          </div>
          <span className="text-[9px] font-black uppercase tracking-[0.3em] text-white/40 group-hover:text-lime-400 transition-colors">
            Book Now
          </span>
        </div>

        {/* Corner Decor - Sharp Industrial Edge */}
        <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-white/5 group-hover:border-lime-400/50 transition-colors pointer-events-none" />
      </div>
    </Link>
  );
}