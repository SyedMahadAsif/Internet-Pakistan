"use client";

import { Zap, ChevronRight, Play, Star } from "lucide-react";

const VENUES = [
  { id: 1, name: "Padel Pro Elite", img: "https://images.unsplash.com/photo-1554068865-24cecd4e34b8?auto=format&fit=crop&w=400&q=80" },
  { id: 2, name: "The Grand Arena", img: "https://images.unsplash.com/photo-1529900903142-1a6e922dfac3?auto=format&fit=crop&w=400&q=80" },
  { id: 3, name: "Kickoff FC Turf", img: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=400&q=80" },
  { id: 4, name: "Smash Hub Badminton", img: "https://images.unsplash.com/photo-1626224580174-29369302636a?auto=format&fit=crop&w=400&q=80" },
];

export default function Header() {
  return (
    <header className="relative z-50 bg-black text-white w-full border-b border-white/5">
      {/* ===== TOP NAV ===== */}
      <nav className="relative z-20 max-w-[1440px] mx-auto h-16 px-6 flex items-center justify-between">
        <div className="flex items-center gap-3 group cursor-pointer">
          <div className="bg-lime-400 p-1.5 transform -skew-x-12 group-hover:skew-x-0 transition-all">
            <Zap size={18} className="text-black fill-black" />
          </div>
          <h1 className="text-lg font-black uppercase tracking-tighter italic">
            Internet <span className="text-lime-400">Pakistan</span>
          </h1>
        </div>
        <div className="flex items-center gap-4">
           <div className="hidden sm:block h-8 w-px bg-white/10" />
           <img src="https://i.pravatar.cc/100" className="w-8 h-8 rounded-full border border-lime-400" alt="Profile" />
        </div>
      </nav>

      

      <style jsx global>{`
        .stroke-text { -webkit-text-stroke: 1px rgba(255,255,255,0.4); color: transparent; }
        @keyframes scroll { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
        .animate-scroll { display: flex; width: max-content; animation: scroll 25s linear infinite; }
        .animate-scroll:hover { animation-play-state: paused; }
        .mask-fade-edges { mask-image: linear-gradient(to right, transparent, black 15%, black 85%, transparent); }
        @media (max-width: 768px) { .stroke-text { -webkit-text-stroke: 0.5px rgba(255,255,255,0.4); } }
      `}</style>
    </header>
  );
}