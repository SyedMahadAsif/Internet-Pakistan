"use client";

import { useRef } from "react";
import { ChevronLeft, ChevronRight, LayoutGrid } from "lucide-react";
import { categories } from "@/data/venues";

export default function CategoryBar({ selectedCategory, setSelectedCategory }) {
  const categoryRef = useRef(null);

  const scroll = (dir) => {
    categoryRef.current?.scrollBy({
      left: dir === "left" ? -320 : 320,
      behavior: "smooth",
    });
  };

  return (
    <div className="bg-black border-y border-white/10 pt-4 pb-6 relative">
      <div className="max-w-[1440px] mx-auto px-6">
        
        {/* TOP BAR: Title & Controls (Prevents Button Cutting) */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="h-1 w-12 bg-lime-400" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/40">Select Discipline</span>
          </div>
          
          <div className="flex gap-px">
            <button
              onClick={() => scroll("left")}
              className="h-8 w-12 flex items-center justify-center bg-[#111] hover:bg-lime-400 text-white hover:text-black border border-white/10 transition-all [clip-path:polygon(20%_0,100%_0,80%_100%,0%_100%)]"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => scroll("right")}
              className="h-8 w-12 flex items-center justify-center bg-[#111] hover:bg-lime-400 text-white hover:text-black border border-white/10 transition-all [clip-path:polygon(20%_0,100%_0,80%_100%,0%_100%)]"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

        {/* Categories Seamless Ribbon */}
        <div className="relative">
          <div
            ref={categoryRef}
            className="flex overflow-x-auto no-scrollbar scroll-smooth pb-4"
          >
            {/* ALL SPORTS TILE */}
            <button
              onClick={() => setSelectedCategory(null)}
              className={`relative flex-shrink-0 w-48 h-32 transition-all duration-300 group -mr-6 z-10`}
            >
              <div className={`absolute inset-0 [clip-path:polygon(0_0,100%_0,85%_100%,0%_100%)] transition-colors duration-500 ${
                selectedCategory === null ? "bg-lime-400 shadow-[10px_0_30px_rgba(163,230,53,0.2)]" : "bg-[#111] border-l border-white/10"
              }`} />
              <div className="absolute inset-0 flex flex-col items-center justify-center z-10 pr-6">
                <LayoutGrid size={24} className={selectedCategory === null ? "text-black" : "text-lime-400"} />
                <span className={`text-[10px] font-black uppercase tracking-[0.3em] mt-2 ${
                  selectedCategory === null ? "text-black" : "text-white/60"
                }`}>All Sports</span>
              </div>
            </button>

            {categories.map((cat) => {
              const isActive = selectedCategory === cat.name;
              return (
                <button
                  key={cat.name}
                  onClick={() => setSelectedCategory(cat.name)}
                  className={`relative flex-shrink-0 w-56 h-32 transition-all duration-300 -mr-6 ${
                    isActive ? "z-30 scale-105" : "z-0 hover:z-20"
                  }`}
                >
                  {/* Seamless Angled Frame */}
                  <div className={`absolute inset-0 [clip-path:polygon(15%_0,100%_0,85%_100%,0%_100%)] overflow-hidden transition-all duration-300 ${
                    isActive ? "ring-2 ring-lime-400" : "opacity-90 hover:opacity-100"
                  }`}>
                    <img
                      src={cat.image}
                      className="w-full h-full object-cover"
                      alt={cat.name}
                    />
                    {/* Gradient for text contrast */}
                    <div className={`absolute inset-0 transition-opacity ${
                      isActive ? "bg-black/40" : "bg-black/60 group-hover:bg-black/40"
                    }`} />
                    
                    {/* Active State Border Highlight */}
                    {/* {isActive && (
                      <div className="absolute inset-y-0 left-[15%] w-1 bg-lime-400 shadow-[0_0_15px_#a3e635]" />
                    )} */}
                  </div>

                  {/* Content */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center z-10 translate-x-[-5%]">
                    <span className={`text-[11px] font-black uppercase tracking-[0.4em] transition-all ${
                      isActive ? "text-lime-400" : "text-white"
                    }`}>
                      {cat.name}
                    </span>
                    {isActive && (
                      <div className="mt-2 h-0.5 w-8 bg-lime-400 rounded-full animate-pulse" />
                    )}
                  </div>
                </button>
              );
            })}
            
            {/* Spacing fix for the last item to prevent clip-path cutoff */}
            <div className="flex-shrink-0 w-12 h-32" />
          </div>
        </div>
      </div>

      <style jsx>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
}