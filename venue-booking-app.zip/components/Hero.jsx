"use client";

import React from "react";
import { ChevronRight, Play, Star, Activity, ArrowUpRight, Zap } from "lucide-react";

const VENUES = [
  { name: "Arena 01", img: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=400", area: "LHR", price: "2.5k" },
  { name: "Padel Pro", img: "https://images.unsplash.com/photo-1554068865-24cecd4e34b8?q=80&w=400", area: "KHI", price: "4.0k" },
  { name: "The Cage", img: "https://images.unsplash.com/photo-1526232761682-d26e03ac148e?q=80&w=400", area: "ISL", price: "3.5k" },
];

export default function Hero() {
  // Duplicating venues for seamless infinite loop
  const scrollItems = [...VENUES, ...VENUES, ...VENUES];

  return (
    <section className="relative w-full h-screen min-h-[600px] flex items-center overflow-hidden bg-[#0a0a0a] text-white">
      
      {/* BACKGROUND DECOR */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute inset-0" style={{ backgroundImage: `radial-gradient(#333 1px, transparent 1px)`, backgroundSize: '30px 30px' }} />
        <div className="absolute top-0 right-0 w-[50%] h-[50%] bg-lime-500/10 blur-[100px] rounded-full" />
      </div>

      <div className="relative z-10 w-full max-w-6xl mx-auto   grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        
        {/* LEFT: BRANDING */}
        <div className="lg:col-span-5 space-y-4">
          <div className="inline-flex items-center gap-2 px-2 py-1 bg-white/5 border border-white/10 rounded">
            <span className="w-1.5 h-1.5 bg-lime-400 rounded-full animate-pulse" />
            <span className="text-[9px] font-bold uppercase tracking-widest text-lime-400">System Live</span>
          </div>

          <h1 className="text-5xl md:text-6xl font-black leading-[0.9] tracking-tighter uppercase italic">
            Elite <span className="text-lime-400">Venues</span><br />
            On Demand
          </h1>

          <p className="max-w-xs text-sm text-white/50 leading-snug">
            Instant booking for Pakistan&apos;s premium sports arenas. High performance, zero friction.
          </p>

          <div className="flex items-center gap-3 pt-2">
            <button className="h-10 px-5 bg-lime-400 text-black font-black uppercase text-[10px] tracking-widest flex items-center gap-2 hover:bg-white transition-all">
              Reserve <ArrowUpRight size={14} />
            </button>
            <button className="h-10 w-10 flex items-center justify-center border border-white/10 hover:bg-white/5">
              <Play size={14} fill="white" />
            </button>
          </div>
        </div>

        {/* RIGHT: CONTENT HUB */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* STATS ROW */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#111] border border-white/5 p-3 rounded flex justify-between items-center">
              <div>
                <p className="text-[8px] font-bold text-white/30 uppercase tracking-[0.2em]">Active Players</p>
                <p className="text-2xl font-black italic">12.8K</p>
              </div>
              <Activity size={16} className="text-lime-400 opacity-50" />
            </div>
            <div className="bg-[#111] border border-white/5 p-3 rounded flex justify-between items-center">
              <div>
                <p className="text-[8px] font-bold text-white/30 uppercase tracking-[0.2em]">Efficiency</p>
                <p className="text-2xl font-black italic">98%</p>
              </div>
              <Zap size={16} className="text-lime-400 opacity-50" />
            </div>
          </div>

          {/* AUTO-CAROUSEL */}
          <div className="relative w-full overflow-hidden">
             {/* Fade Edges Mask */}
            <div className="absolute inset-y-0 left-0 w-12 bg-gradient-to-r from-[#0a0a0a] to-transparent z-10" />
            <div className="absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-[#0a0a0a] to-transparent z-10" />

            <div className="flex gap-4 animate-carousel py-2">
              {scrollItems.map((v, i) => (
                <div key={i} className="flex-shrink-0 w-48 group">
                  <div className="relative aspect-[4/5] overflow-hidden rounded-lg border border-white/10">
                    <img 
                      src={v.img} 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                      alt="" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                    
                    <div className="absolute bottom-2 left-2 right-2">
                      <p className="text-[10px] font-black uppercase italic leading-none">{v.name}</p>
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-[9px] font-bold text-white/60 uppercase">{v.area}</span>
                        <div className="flex items-center gap-0.5">
                          <Star size={8} fill="#a3e635" className="text-lime-400 border-none" />
                          <span className="text-[8px] font-bold">4.9</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* PARTNER STRIP */}
          <div className="bg-white/5 border-y border-white/5 py-2 overflow-hidden flex items-center gap-10">
            <div className="flex gap-10 animate-marquee whitespace-nowrap">
              {['ADIDAS PERFORMANCE', 'FOOTBALL PAKISTAN', 'REDBULL STUDIOS', 'FLY EMIRATES', 'ADIDAS PERFORMANCE'].map((t, idx) => (
                <span key={idx} className="text-[8px] font-black text-white/20 tracking-[0.3em]">{t}</span>
              ))}
            </div>
          </div>

        </div>
      </div>

      <style jsx global>{`
        @keyframes carousel {
          0% { transform: translateX(0); }
          100% { transform: translateX(calc(-192px * 3 - 1rem * 3)); }
        }
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-carousel {
          animation: carousel 20s linear infinite;
        }
        .animate-carousel:hover {
          animation-play-state: paused;
        }
        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
      `}</style>
    </section>
  );
}