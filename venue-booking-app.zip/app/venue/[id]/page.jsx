"use client";

import { useParams, useRouter } from "next/navigation";
import { ChevronLeft } from "lucide-react";
import Header from "@/components/Header";
import VenueInfo from "@/components/VenueInfo";
import VenueHero from "@/components/VenueHero";
import VenueMap from "@/components/VenueMap";
import { venues } from "@/data/venues";

export default function VenueDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const venue = venues.find((v) => v.id === parseInt(params.id));

  if (!venue) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-black mb-4">Venue Not Found</h1>
          <button
            onClick={() => router.push("/")}
            className="bg-lime-400 text-black px-6 py-3 rounded-xl font-black"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white overflow-x-hidden">
      <Header />

      <main className="max-w-[1600px] mx-auto px-4 lg:px-8 py-6">
        <button
          onClick={() => router.push("/")}
          className="flex items-center gap-2 text-lime-400 hover:text-lime-300 transition text-sm font-bold mb-6"
        >
          <ChevronLeft size={18} />
          Back to all venues
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* LEFT - Venue Info */}
          <div className="space-y-4">
            <VenueInfo venue={venue} />
          </div>

          {/* RIGHT - Hero Image & Map */}
          <div className="space-y-4">
            <VenueHero venue={venue} />
            <VenueMap venue={venue} />
          </div>
        </div>
      </main>
    </div>
  );
}
